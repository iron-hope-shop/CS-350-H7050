#include <stdint.h>
#include <stddef.h>

/* Driver Header files */
#include <ti/drivers/GPIO.h>
#include <ti/drivers/UART2.h>

/* Driver configuration */
#include "ti_drivers_config.h"

/* State machine states */
typedef enum {
    WAIT_FOR_COMMAND,
    TURN_LED_ON,
    TURN_LED_OFF
} State;

/*
 *  ======== mainThread ========
 */
void *mainThread(void *arg0)
{
    char input;
    UART2_Handle uart;
    UART2_Params uartParams;
    size_t bytesRead;
    size_t bytesWritten = 0;
    uint32_t status     = UART2_STATUS_SUCCESS;
    State state = WAIT_FOR_COMMAND;

    /* Call driver init functions */
    GPIO_init();

    /* Configure the LED pin */
    GPIO_setConfig(CONFIG_GPIO_LED_0, GPIO_CFG_OUT_STD | GPIO_CFG_OUT_LOW);

    /* Create a UART where the default read and write mode is BLOCKING */
    UART2_Params_init(&uartParams);
    uartParams.baudRate = 115200;

    uart = UART2_open(CONFIG_UART2_0, &uartParams);

    if (uart == NULL) {
        /* UART2_open() failed */
        while (1) {}
    }

    /* Turn on user LED to indicate successful initialization */
    GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_ON);

    /* Loop forever echoing */
    while (1) {
        bytesRead = 0;
        status = UART2_read(uart, &input, 1, &bytesRead);

        if (status != UART2_STATUS_SUCCESS) {
            /* UART2_read() failed */
            while (1) {}
        }

        if (bytesRead > 0) {
            switch (state) {
                case WAIT_FOR_COMMAND:
                    if (input == 'O') {
                        state = TURN_LED_ON;
                    } else if (input == 'F') {
                        state = TURN_LED_OFF;
                    }
                    break;
                case TURN_LED_ON:
                    GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_ON);
                    state = WAIT_FOR_COMMAND;
                    break;
                case TURN_LED_OFF:
                    GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_OFF);
                    state = WAIT_FOR_COMMAND;
                    break;
                default:
                    state = WAIT_FOR_COMMAND;
                    break;
            }

            /* Respond back to the UART to acknowledge the command received */
            bytesWritten = 0;
            status = UART2_write(uart, &input, 1, &bytesWritten);

            if (status != UART2_STATUS_SUCCESS) {
                /* UART2_write() failed */
                while (1) {}
            }

            /* Handle the situation where the state machine ends up in an unexpected state */
            if (state == WAIT_FOR_COMMAND && input != 'O' && input != 'F') {
                /* If we receive a character other than 'O' or 'F', we ignore it and reset to WAIT_FOR_COMMAND state */
                state = WAIT_FOR_COMMAND;
            }
        }
    }
}



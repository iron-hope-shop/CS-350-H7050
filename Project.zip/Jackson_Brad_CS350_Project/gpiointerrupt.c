#include <stdint.h>
#include <stddef.h>
#include <stdio.h>
#include <string.h>

#include <ti/drivers/GPIO.h>
#include <ti/drivers/I2C.h>
#include <ti/drivers/UART2.h>
#include <ti/drivers/Timer.h>

#include "ti_drivers_config.h"

char output[64];
int bytesToSend;
UART2_Handle uart;

Timer_Handle timer0;
volatile unsigned char TimerFlag = 0;

void initUART(void);
void initI2C(void);
void initTimer(void);
void timerCallback(Timer_Handle myHandle, int_fast16_t status);
int16_t readTemp(void);

volatile int setPointTemp = 20;
volatile int16_t currentTemp = 0;
volatile unsigned int elapsedTime = 0;
volatile unsigned int lastButtonPressTime = 0;

#define DISPLAY(format, ...)                                      \
    do                                                            \
    {                                                             \
        snprintf(output, sizeof(output), format, ##__VA_ARGS__);  \
        size_t bytesWritten;                                      \
        UART2_write(uart, output, strlen(output), &bytesWritten); \
    } while (0)

void gpioButtonFxn0(uint_least8_t index)
{
    if (elapsedTime - lastButtonPressTime > 200)
    {
        setPointTemp += 1;
        lastButtonPressTime = elapsedTime;
        DISPLAY("Button pressed. Set-point temperature: %d\n", setPointTemp);
    }
    else
    {
        DISPLAY("Button press ignored (debounce).\n");
    }
}

void gpioButtonFxn1(uint_least8_t index)
{
    if (elapsedTime - lastButtonPressTime > 200)
    {
        setPointTemp -= 1;
        lastButtonPressTime = elapsedTime;
        DISPLAY("Button pressed. Set-point temperature: %d\n", setPointTemp);
    }
    else
    {
        DISPLAY("Button press ignored (debounce).\n");
    }
}

void initUART(void)
{
    UART2_Params uartParams;
    uartParams.baudRate = 115200;
    UART2_Params_init(&uartParams);
    uartParams.writeMode = UART2_Mode_BLOCKING;
    uartParams.readMode = UART2_Mode_BLOCKING;
    uart = UART2_open(CONFIG_UART2_0, &uartParams);
    if (uart == NULL)
    {
        while (1)
            ;
    }
}

static const struct
{
    uint8_t address;
    uint8_t resultReg;
    char *id;
} sensors[3] = {
    {0x48, 0x0000, "11X"},
    {0x49, 0x0000, "116"},
    {0x41, 0x0001, "006"}};
    uint8_t txBuffer[1];
    uint8_t rxBuffer[2];
    I2C_Transaction i2cTransaction;
    I2C_Handle i2c;

void initI2C(void)
{
    int8_t found;
    I2C_Params i2cParams;
    I2C_Handle i2c;
    uint8_t txBuffer[1];
    uint8_t rxBuffer[2];
    I2C_Transaction i2cTransaction;

    I2C_init();
    I2C_Params_init(&i2cParams);
    i2cParams.bitRate = I2C_400kHz;
    i2c = I2C_open(CONFIG_I2C_0, &i2cParams);
    if (i2c == NULL)
    {
        DISPLAY("Failed to open I2C\n\r");
        while (1)
            ;
    }
    DISPLAY("I2C Initialized\n\r");
    i2cTransaction.writeBuf = txBuffer;
    i2cTransaction.writeCount = 1;
    i2cTransaction.readBuf = rxBuffer;
    i2cTransaction.readCount = 0;
    found = false;
    for (int i = 0; i < 3; ++i)
    {
        txBuffer[0] = sensors[i].resultReg;
        i2cTransaction.writeBuf = txBuffer;
        i2cTransaction.writeCount = 1;
        i2cTransaction.readBuf = rxBuffer;
        i2cTransaction.readCount = sizeof(rxBuffer);
        DISPLAY("Is this?");
        if (I2C_transfer(i2c, &i2cTransaction))
        {
            DISPLAY("Found\n\r");
            found = true;
            break;
        }
        DISPLAY("No\n\r");
    }
    if (!found)
    {
        DISPLAY("Temperature sensor not found\n\r");
    }
}

int16_t readTemp(void)
{
    int16_t temperature = 0;
    i2cTransaction.readCount = 2;
    if (I2C_transfer(i2c, &i2cTransaction))
    {
        temperature = (rxBuffer[0] << 8) | (rxBuffer[1]);
        temperature *= 0.0078125;
        if (rxBuffer[0] & 0x80)
        {
            temperature |= 0xF000;
        }
    }
    else
    {
        DISPLAY("Error reading temperature sensor, please power cycle your board");
    }
    return temperature;
}

void initTimer(void)
{
    Timer_Params params;
    Timer_init();
    Timer_Params_init(&params);
    params.period = 100000;
    params.periodUnits = Timer_PERIOD_US;
    params.timerMode = Timer_CONTINUOUS_CALLBACK;
    params.timerCallback = timerCallback;
    timer0 = Timer_open(CONFIG_TIMER_0, &params);
    if (timer0 == NULL)
    {
        while (1)
            ;
    }
    if (Timer_start(timer0) == Timer_STATUS_ERROR)
    {
        while (1)
            ;
    }
}

void timerCallback(Timer_Handle myHandle, int_fast16_t status)
{
    TimerFlag = 1;
    elapsedTime += 100;
}

void checkTemperatureAndUpdateLED()
{
    currentTemp = readTemp();
    DISPLAY("Current temperature: %d, Set-point: %d\n", currentTemp, setPointTemp);

    if (currentTemp < setPointTemp)
    {
        GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_ON);
        DISPLAY("LED ON (Heater)\n");
    }
    else
    {
        GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_OFF);
        DISPLAY("LED OFF (Heater)\n");
    }
}

void reportToServer()
{
    int heaterStatus = GPIO_read(CONFIG_GPIO_LED_0);
    int secondsSinceReset = elapsedTime / 1000;
    DISPLAY("<%02d,%02d,%d,%04d>\n", currentTemp, setPointTemp, heaterStatus, secondsSinceReset);
}

void *mainThread(void *arg0)
{
    initUART();
    DISPLAY("UART initialized.\n");
    initI2C();
    DISPLAY("I2C initialized.\n");
    initTimer();
    DISPLAY("Timer initialized.\n");

    GPIO_setConfig(CONFIG_GPIO_LED_0, GPIO_CFG_OUT_STD | GPIO_CFG_OUT_LOW);
    GPIO_setConfig(CONFIG_GPIO_BUTTON_0, GPIO_CFG_IN_PU | GPIO_CFG_IN_INT_FALLING);
    GPIO_setConfig(CONFIG_GPIO_BUTTON_1, GPIO_CFG_IN_PU | GPIO_CFG_IN_INT_FALLING);
    GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_ON);
    DISPLAY("GPIO configured.\n");

    GPIO_setCallback(CONFIG_GPIO_BUTTON_0, gpioButtonFxn0);
    GPIO_setCallback(CONFIG_GPIO_BUTTON_1, gpioButtonFxn1);
    GPIO_enableInt(CONFIG_GPIO_BUTTON_0);
    GPIO_enableInt(CONFIG_GPIO_BUTTON_1);
    DISPLAY("Button callback set.\n");

    unsigned int last200ms = 0;
    unsigned int last500ms = 0;
    unsigned int last1000ms = 0;

    while (1)
    {
        if (TimerFlag)
        {
            TimerFlag = 0;

            if (elapsedTime - last200ms >= 200)
            {
                last200ms = elapsedTime;
                DISPLAY("200ms task.\n");
            }

            if (elapsedTime - last500ms >= 500)
            {
                checkTemperatureAndUpdateLED();
                last500ms = elapsedTime;
            }

            if (elapsedTime - last1000ms >= 1000)
            {
                reportToServer();
                last1000ms = elapsedTime;
            }
        }
    }

    return (NULL);
}
